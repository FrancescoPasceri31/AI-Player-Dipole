package testing;

public class LauncherApp {

	public static void main(String[] args) {
		Scacchiera scacchiera = new Scacchiera();
		scacchiera.show();
	}
}
